package com.example

/**
 * ملف التكوين الرئيسي للتطبيق (baby.kt)
 * يحتوي على البيانات والأساسيات للمحل، الوصل، والعملة.
 * أي تعديل في هذا الملف ينعكس تلقائياً على كامل التطبيق.
 */
object BabyConfig {
    const val USER_NAME = "علي"
    const val APP_NAME = "دفتر الديون"
    const val APP_SUBTITLE = "إدارة الديون والعملاء"
    const val STORE_NAME = "لايبو للخدمات التجارية"
    const val PHONE_NUMBER = "07701234567"
    const val CURRENCY = "د.ع"
    const val RECEIPT_FOOTER = "شكراً لتعاملكم معنا - نتمنى لكم يوماً سعيداً"
    const val DEFAULT_PAPER_SIZE = "58mm" // "58mm" أو "80mm"
    const val APP_VERSION = "1.0.0"
    const val MAX_CUSTOMERS_FREE = Int.MAX_VALUE
    const val SUBSCRIPTION_MESSAGE = "يرجى الاشتراك في النسخة الكاملة لتمتع في كافة مميزات البرنامج"
}
