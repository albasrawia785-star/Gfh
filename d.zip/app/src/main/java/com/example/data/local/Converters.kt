package com.example.data.local

import androidx.room.TypeConverter
import com.example.data.model.OperationType

class Converters {
    @TypeConverter
    fun fromOperationType(type: OperationType): String {
        return type.name
    }

    @TypeConverter
    fun toOperationType(value: String): OperationType {
        return try {
            OperationType.valueOf(value)
        } catch (e: Exception) {
            OperationType.DEBT
        }
    }
}
