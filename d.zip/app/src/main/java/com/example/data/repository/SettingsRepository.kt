package com.example.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "app_settings")

class SettingsRepository(private val context: Context) {

    companion object {
        val OVERDUE_DAYS_KEY = intPreferencesKey("overdue_days_threshold")
        val NOTIFICATIONS_ENABLED_KEY = booleanPreferencesKey("notifications_enabled")
        val IS_LOGGED_IN_KEY = booleanPreferencesKey("is_logged_in")
        const val DEFAULT_OVERDUE_DAYS = 30
    }

    val isLoggedIn: Flow<Boolean> = context.settingsDataStore.data.map { prefs ->
        prefs[IS_LOGGED_IN_KEY] ?: false
    }

    suspend fun setLoggedIn(loggedIn: Boolean) {
        context.settingsDataStore.edit { prefs ->
            prefs[IS_LOGGED_IN_KEY] = loggedIn
        }
    }

    val overdueDays: Flow<Int> = context.settingsDataStore.data.map { prefs ->
        prefs[OVERDUE_DAYS_KEY] ?: DEFAULT_OVERDUE_DAYS
    }

    val isNotificationsEnabled: Flow<Boolean> = context.settingsDataStore.data.map { prefs ->
        prefs[NOTIFICATIONS_ENABLED_KEY] ?: true
    }

    suspend fun saveOverdueDays(days: Int) {
        context.settingsDataStore.edit { prefs ->
            prefs[OVERDUE_DAYS_KEY] = days
        }
    }

    suspend fun saveNotificationsEnabled(enabled: Boolean) {
        context.settingsDataStore.edit { prefs ->
            prefs[NOTIFICATIONS_ENABLED_KEY] = enabled
        }
    }
}
