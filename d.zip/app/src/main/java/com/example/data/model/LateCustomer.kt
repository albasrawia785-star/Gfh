package com.example.data.model

data class LateCustomer(
    val customer: Customer,
    val daysOverdue: Int,
    val lastDebtDate: Long
)
