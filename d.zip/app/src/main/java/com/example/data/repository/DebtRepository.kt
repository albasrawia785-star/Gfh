package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.model.Customer
import com.example.data.model.Operation
import com.example.data.model.OperationType
import com.example.data.model.OperationWithCustomer
import com.example.util.formatCurrency
import kotlinx.coroutines.flow.Flow

data class AddOperationResult(
    val operationId: Long,
    val isZeroDebtReached: Boolean,
    val updatedCustomer: Customer,
    val operation: Operation
)

class DebtRepository(private val database: AppDatabase) {
    private val customerDao = database.customerDao()
    private val operationDao = database.operationDao()

    val allCustomers: Flow<List<Customer>> = customerDao.getAllCustomers()
    val totalDebtSum: Flow<Long?> = customerDao.getTotalDebtSum()
    val customerCount: Flow<Int> = customerDao.getCustomerCount()
    val totalDebtAddedSum: Flow<Long?> = operationDao.getTotalDebtAddedSum()
    val totalPaymentsSum: Flow<Long?> = operationDao.getTotalPaymentsSum()
    val allOperationsWithCustomer: Flow<List<OperationWithCustomer>> = operationDao.getAllOperationsWithCustomer()

    fun getOperationsForCustomer(customerId: Long): Flow<List<Operation>> {
        return operationDao.getOperationsForCustomer(customerId)
    }

    fun searchCustomers(query: String): Flow<List<Customer>> {
        return if (query.isBlank()) {
            customerDao.getAllCustomers()
        } else {
            customerDao.searchCustomersByName(query.trim())
        }
    }

    suspend fun getCustomerById(id: Long): Customer? = customerDao.getCustomerById(id)

    suspend fun addCustomer(name: String, phone: String?, initialDebt: Long): Result<Long> {
        val trimmedName = name.trim()
        if (trimmedName.isEmpty()) {
            return Result.failure(IllegalArgumentException("اسم المدين مطلوب"))
        }

        if (initialDebt <= 0L) {
            return Result.failure(IllegalArgumentException("مبلغ الدين الأولي يجب أن يكون أكبر من صفر"))
        }

        val existing = customerDao.getCustomerByName(trimmedName)
        if (existing != null) {
            return Result.failure(IllegalStateException("اسم المدين موجود بالفعل"))
        }

        val customer = Customer(
            name = trimmedName,
            phone = phone?.trim()?.ifEmpty { null },
            debtAmount = initialDebt
        )

        return try {
            val customerId = database.withTransaction {
                val id = customerDao.insertCustomer(customer)
                val initialOp = Operation(
                    customerId = id,
                    type = OperationType.DEBT,
                    amount = initialDebt,
                    note = "دين أولي",
                    dateTime = System.currentTimeMillis()
                )
                operationDao.insertOperation(initialOp)
                id
            }
            Result.success(customerId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateCustomer(customer: Customer): Result<Unit> {
        val trimmedName = customer.name.trim()
        if (trimmedName.isEmpty()) {
            return Result.failure(IllegalArgumentException("اسم المدين مطلوب"))
        }

        val existing = customerDao.getCustomerByName(trimmedName)
        if (existing != null && existing.id != customer.id) {
            return Result.failure(IllegalStateException("اسم المدين هذا مستخدم بالفعل"))
        }

        return try {
            customerDao.updateCustomer(customer.copy(name = trimmedName, phone = customer.phone?.trim()?.ifEmpty { null }))
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteCustomer(customer: Customer): Result<Unit> {
        return try {
            customerDao.deleteCustomer(customer)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun addOperation(
        customerId: Long,
        type: OperationType,
        amount: Long,
        note: String
    ): Result<AddOperationResult> {
        if (amount <= 0) {
            return Result.failure(IllegalArgumentException("يجب أن يكون المبلغ أكبر من صفر"))
        }

        return try {
            val result = database.withTransaction {
                val customer = customerDao.getCustomerById(customerId)
                    ?: throw IllegalStateException("المدين غير موجود")

                val newDebtAmount = when (type) {
                    OperationType.DEBT -> customer.debtAmount + amount
                    OperationType.PAYMENT -> {
                        if (amount > customer.debtAmount) {
                            throw IllegalArgumentException("المبلغ المراد تسديده أكبر من الدين الحالي (${customer.debtAmount.formatCurrency()})")
                        }
                        customer.debtAmount - amount
                    }
                }

                val updatedCustomer = customer.copy(debtAmount = newDebtAmount)
                customerDao.updateCustomer(updatedCustomer)

                val operation = Operation(
                    customerId = customerId,
                    type = type,
                    amount = amount,
                    note = note.trim(),
                    dateTime = System.currentTimeMillis()
                )
                val opId = operationDao.insertOperation(operation)

                val isZeroDebt = (type == OperationType.PAYMENT && newDebtAmount == 0L)
                AddOperationResult(
                    operationId = opId,
                    isZeroDebtReached = isZeroDebt,
                    updatedCustomer = updatedCustomer,
                    operation = operation.copy(id = opId)
                )
            }
            Result.success(result)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteOperation(opWithCustomer: OperationWithCustomer): Result<Unit> {
        val op = opWithCustomer.operation
        val customerId = op.customerId

        return try {
            database.withTransaction {
                val customer = customerDao.getCustomerById(customerId)
                if (customer != null) {
                    val recalculatedDebt = when (op.type) {
                        OperationType.DEBT -> {
                            // Reverting debt creation: subtract amount
                            (customer.debtAmount - op.amount).coerceAtLeast(0L)
                        }
                        OperationType.PAYMENT -> {
                            // Reverting payment: add amount back
                            customer.debtAmount + op.amount
                        }
                    }
                    customerDao.updateCustomer(customer.copy(debtAmount = recalculatedDebt))
                }
                operationDao.deleteOperation(op)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
