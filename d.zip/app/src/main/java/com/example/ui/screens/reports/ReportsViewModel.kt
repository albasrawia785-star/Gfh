package com.example.ui.screens.reports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.Customer
import com.example.data.model.OperationType
import com.example.data.model.OperationWithCustomer
import com.example.data.repository.DebtRepository
import com.example.data.repository.SettingsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class ReportsUiState(
    val totalDebt: Long = 0L,
    val customerCount: Int = 0,
    val lateCustomersCount: Int = 0,
    val totalDebtAdded: Long = 0L,
    val totalPayments: Long = 0L,
    val netDebt: Long = 0L
)

private data class PrimaryStats(
    val totalDebt: Long?,
    val customerCount: Int,
    val customers: List<Customer>,
    val operationsWithCustomer: List<OperationWithCustomer>
)

private data class SecondaryStats(
    val threshold: Int,
    val totalAdded: Long?,
    val totalPayments: Long?
)

class ReportsViewModel(
    private val repository: DebtRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val primaryStatsFlow = combine(
        repository.totalDebtSum,
        repository.customerCount,
        repository.allCustomers,
        repository.allOperationsWithCustomer
    ) { totalDebt, customerCount, customers, operations ->
        PrimaryStats(totalDebt, customerCount, customers, operations)
    }

    private val secondaryStatsFlow = combine(
        settingsRepository.overdueDays,
        repository.totalDebtAddedSum,
        repository.totalPaymentsSum
    ) { threshold, totalAdded, totalPayments ->
        SecondaryStats(threshold, totalAdded, totalPayments)
    }

    val uiState: StateFlow<ReportsUiState> = combine(
        primaryStatsFlow,
        secondaryStatsFlow
    ) { primary, secondary ->
        val now = System.currentTimeMillis()
        val oneDayMs = 1000L * 60 * 60 * 24

        val lateCount = primary.customers
            .filter { it.debtAmount > 0 }
            .count { customer ->
                val customerDebtOps = primary.operationsWithCustomer
                    .map { it.operation }
                    .filter { it.customerId == customer.id && it.type == OperationType.DEBT }
                val lastDebtTime = customerDebtOps.maxOfOrNull { it.dateTime }

                if (lastDebtTime != null) {
                    val daysPassed = ((now - lastDebtTime) / oneDayMs).toInt().coerceAtLeast(0)
                    daysPassed > secondary.threshold
                } else false
            }

        val debtVal = primary.totalDebt ?: 0L
        val addedVal = secondary.totalAdded ?: 0L
        val paymentsVal = secondary.totalPayments ?: 0L
        val netVal = addedVal - paymentsVal

        ReportsUiState(
            totalDebt = debtVal,
            customerCount = primary.customerCount,
            lateCustomersCount = lateCount,
            totalDebtAdded = addedVal,
            totalPayments = paymentsVal,
            netDebt = netVal
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = ReportsUiState()
    )

    class Factory(
        private val repository: DebtRepository,
        private val settingsRepository: SettingsRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ReportsViewModel(repository, settingsRepository) as T
        }
    }
}
