package com.example.ui.screens.main

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.Customer
import com.example.data.model.Operation
import com.example.data.model.OperationType
import com.example.data.repository.DebtRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

import com.example.BabyConfig

import com.example.data.repository.SettingsRepository

sealed class UiMessage {
    data class ShowToast(val message: String) : UiMessage()
    data class PromptZeroDebtDelete(val customer: Customer) : UiMessage()
    object ShowSubscriptionDialog : UiMessage()
}

class MainViewModel(
    private val repository: DebtRepository,
    private val settingsRepository: SettingsRepository? = null
) : ViewModel() {

    val isNotificationsEnabled: StateFlow<Boolean> = (settingsRepository?.isNotificationsEnabled ?: MutableStateFlow(true))
        .stateIn(
            scope = viewModelScope,
            started = kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000),
            initialValue = true
        )

    fun toggleNotifications() {
        viewModelScope.launch {
            val currentState = isNotificationsEnabled.value
            val newState = !currentState
            settingsRepository?.saveNotificationsEnabled(newState)
            if (newState) {
                _uiEvent.emit(UiMessage.ShowToast("تم تشغيل الإشعارات والتنبيهات 🔔"))
            } else {
                _uiEvent.emit(UiMessage.ShowToast("تم إيقاف الإشعارات والتنبيهات 🔕"))
            }
        }
    }

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val customers: StateFlow<List<Customer>> = _searchQuery
        .flatMapLatest { query -> repository.searchCustomers(query) }
        .stateIn(
            scope = viewModelScope,
            started = kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val totalDebt: StateFlow<Long> = repository.totalDebtSum
        .combine(MutableStateFlow(0L)) { sum, _ -> sum ?: 0L }
        .stateIn(
            scope = viewModelScope,
            started = kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000),
            initialValue = 0L
        )

    val customerCount: StateFlow<Int> = repository.customerCount
        .stateIn(
            scope = viewModelScope,
            started = kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    fun getOperationsForCustomer(customerId: Long) = repository.getOperationsForCustomer(customerId)

    private val _uiEvent = MutableSharedFlow<UiMessage>()
    val uiEvent: SharedFlow<UiMessage> = _uiEvent.asSharedFlow()

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun addCustomer(name: String, phone: String?, initialDebt: Long, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val result = repository.addCustomer(name, phone, initialDebt)
            result.onSuccess {
                _uiEvent.emit(UiMessage.ShowToast("تمت إضافة المدين وسجل الدين الأولي بنجاح"))
                onSuccess()
            }.onFailure { e ->
                _uiEvent.emit(UiMessage.ShowToast(e.message ?: "حدث خطأ أثناء إضافة المدين"))
            }
        }
    }

    fun updateCustomer(customer: Customer, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val result = repository.updateCustomer(customer)
            result.onSuccess {
                _uiEvent.emit(UiMessage.ShowToast("تم تعديل بيانات المدين بنجاح"))
                onSuccess()
            }.onFailure { e ->
                _uiEvent.emit(UiMessage.ShowToast(e.message ?: "حدث خطأ أثناء التعديل"))
            }
        }
    }

    fun deleteCustomer(customer: Customer) {
        viewModelScope.launch {
            val result = repository.deleteCustomer(customer)
            result.onSuccess {
                _uiEvent.emit(UiMessage.ShowToast("تم حذف المدين بنجاح"))
            }.onFailure { e ->
                _uiEvent.emit(UiMessage.ShowToast(e.message ?: "حدث خطأ أثناء الحذف"))
            }
        }
    }

    fun addOperation(
        customerId: Long,
        type: OperationType,
        amount: Long,
        note: String,
        printAfterSave: Boolean = false,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.addOperation(customerId, type, amount, note)
            result.onSuccess { opResult ->
                val typeName = if (type == OperationType.DEBT) "دين جديد" else "تسديد"
                _uiEvent.emit(UiMessage.ShowToast("تم تسجيل عملية $typeName بنجاح"))
                onSuccess()

                if (opResult.isZeroDebtReached) {
                    _uiEvent.emit(UiMessage.PromptZeroDebtDelete(opResult.updatedCustomer))
                }
            }.onFailure { e ->
                _uiEvent.emit(UiMessage.ShowToast(e.message ?: "فشلت العملية"))
            }
        }
    }

    class Factory(
        private val repository: DebtRepository,
        private val settingsRepository: SettingsRepository? = null
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MainViewModel(repository, settingsRepository) as T
        }
    }
}

