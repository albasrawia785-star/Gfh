package com.example.ui.screens.operations

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.OperationType
import com.example.data.model.OperationWithCustomer
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SurfaceLight
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.util.formatCurrency
import com.example.util.formatDateTime

enum class OperationFilter {
    ALL, DEBT_ONLY, PAYMENT_ONLY
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OperationsScreen(
    viewModel: OperationsViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val operations by viewModel.operations.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val customers by viewModel.customers.collectAsStateWithLifecycle()
    val selectedCustomer by viewModel.selectedCustomer.collectAsStateWithLifecycle()

    var selectedFilter by remember { mutableStateOf(OperationFilter.ALL) }
    var operationToDelete by remember { mutableStateOf<OperationWithCustomer?>(null) }

    LaunchedEffect(Unit) {
        viewModel.uiEvent.collect { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }

    val filteredOperations = remember(operations, selectedFilter) {
        when (selectedFilter) {
            OperationFilter.ALL -> operations
            OperationFilter.DEBT_ONLY -> operations.filter { it.operation.type == OperationType.DEBT }
            OperationFilter.PAYMENT_ONLY -> operations.filter { it.operation.type == OperationType.PAYMENT }
        }
    }

    Scaffold(
        containerColor = SurfaceLight,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // Header Title
            Text(
                text = if (selectedCustomer != null) "كشف حساب ${selectedCustomer?.name}" else "سجل العمليات",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryDark,
                    fontSize = 20.sp
                ),
                modifier = Modifier.padding(top = 12.dp, bottom = 8.dp)
            )

            // 1. Customer Selection Bar (Horizontal Chips for selecting each customer)
            Text(
                text = "اختر المدين لعرض عملياته الخاصة:",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondaryDark,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // All Customers Chip
                item {
                    FilterChip(
                        selected = selectedCustomer == null,
                        onClick = { viewModel.selectCustomer(null) },
                        label = { Text("جميع المدينين") },
                        shape = CircleShape,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = RoyalBlue,
                            selectedLabelColor = Color.White,
                            containerColor = Color.White,
                            labelColor = TextSecondaryDark
                        )
                    )
                }

                // Individual Customer Chips
                items(customers, key = { it.id }) { customer ->
                    val isSelected = selectedCustomer?.id == customer.id
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.selectCustomer(customer) },
                        label = { Text(customer.name) },
                        shape = CircleShape,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = RoyalBlue,
                            selectedLabelColor = Color.White,
                            containerColor = Color.White,
                            labelColor = TextSecondaryDark
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Search Bar Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.updateSearchQuery(it) },
                modifier = Modifier.fillMaxWidth(),
                placeholder = {
                    Text(
                        text = if (selectedCustomer != null) "بحث في عمليات ${selectedCustomer?.name}..." else "بحث في عمليات كل المدينين...",
                        color = TextSecondaryDark,
                        fontSize = 14.sp
                    )
                },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = TextSecondaryDark) },
                singleLine = true,
                shape = CircleShape,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedBorderColor = RoyalBlue,
                    unfocusedBorderColor = BorderLight
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 2. Selected Customer Dedicated Summary Banner Card
            selectedCustomer?.let { cust ->
                val totalDebtAdded = operations.filter { it.operation.type == OperationType.DEBT }.sumOf { it.operation.amount }
                val totalPaid = operations.filter { it.operation.type == OperationType.PAYMENT }.sumOf { it.operation.amount }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Column {
                            Text(
                                text = "كشف حساب: ${cust.name}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = TextPrimaryDark
                            )
                            cust.phone?.let {
                                Text(
                                    text = it,
                                    fontSize = 12.sp,
                                    color = TextSecondaryDark
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("إجمالي الديون المضافة", fontSize = 11.sp, color = TextSecondaryDark)
                                Text(totalDebtAdded.formatCurrency(), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = CrimsonRed)
                            }
                            Column {
                                Text("إجمالي المسدد", fontSize = 11.sp, color = TextSecondaryDark)
                                Text(totalPaid.formatCurrency(), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = EmeraldGreen)
                            }
                            Column {
                                Text("المتبقي الحالي", fontSize = 11.sp, color = TextSecondaryDark)
                                Text(cust.debtAmount.formatCurrency(), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = RoyalBlue)
                            }
                        }
                    }
                }
            }


            // 3. Operation Type Filter Chips (الكل / دين جديد / تسديد)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedFilter == OperationFilter.ALL,
                    onClick = { selectedFilter = OperationFilter.ALL },
                    label = { Text("الكل") },
                    shape = CircleShape,
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = RoyalBlue,
                        selectedLabelColor = Color.White,
                        containerColor = Color.White,
                        labelColor = TextSecondaryDark
                    )
                )

                FilterChip(
                    selected = selectedFilter == OperationFilter.DEBT_ONLY,
                    onClick = { selectedFilter = OperationFilter.DEBT_ONLY },
                    label = { Text("ديون فقط") },
                    shape = CircleShape,
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = RoyalBlue,
                        selectedLabelColor = Color.White,
                        containerColor = Color.White,
                        labelColor = TextSecondaryDark
                    )
                )

                FilterChip(
                    selected = selectedFilter == OperationFilter.PAYMENT_ONLY,
                    onClick = { selectedFilter = OperationFilter.PAYMENT_ONLY },
                    label = { Text("تسديدات فقط") },
                    shape = CircleShape,
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = RoyalBlue,
                        selectedLabelColor = Color.White,
                        containerColor = Color.White,
                        labelColor = TextSecondaryDark
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (filteredOperations.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = Color.Gray.copy(alpha = 0.4f)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (selectedCustomer != null)
                                "لا توجد عمليات مسجلة للمدين \"${selectedCustomer?.name}\""
                            else if (searchQuery.isBlank())
                                "لا يوجد سجل عمليات بعد"
                            else
                                "لا توجد عمليات تطابق البحث",
                            color = TextSecondaryDark
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredOperations, key = { it.operation.id }) { opWithCustomer ->
                        OperationCard(
                            opWithCustomer = opWithCustomer,
                            onDelete = { operationToDelete = opWithCustomer }
                        )
                    }

                }
            }
        }
    }

    // Delete Operation Confirmation Dialog
    operationToDelete?.let { opWithCustomer ->
        AlertDialog(
            onDismissRequest = { operationToDelete = null },
            title = { Text("حذف العملية وإعادة الاحتساب", fontWeight = FontWeight.Bold) },
            text = {
                val op = opWithCustomer.operation
                val typeName = if (op.type == OperationType.DEBT) "دين جديد" else "تسديد"
                val customerName = opWithCustomer.customer?.name ?: "المدين"
                Text("هل أنت تأكد من حذف عملية \"$typeName\" بمبلغ ${op.amount.formatCurrency()} لـ $customerName؟\n\nسيتم إعادة احتساب وتحديث ديون المدين تلقائياً.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteOperation(opWithCustomer)
                        operationToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed)
                ) {
                    Text("حذف وتحديث الدين")
                }
            },
            dismissButton = {
                TextButton(onClick = { operationToDelete = null }) {
                    Text("إلغاء")
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White
        )
    }
}

@Composable
fun OperationCard(
    opWithCustomer: OperationWithCustomer,
    onDelete: () -> Unit
) {
    val op = opWithCustomer.operation
    val customerName = opWithCustomer.customer?.name ?: "مدين محذوف"
    val isDebt = op.type == OperationType.DEBT

    val badgeBg = if (isDebt) CrimsonRed.copy(alpha = 0.12f) else EmeraldGreen.copy(alpha = 0.12f)
    val badgeColor = if (isDebt) CrimsonRed else EmeraldGreen
    val typeLabel = if (isDebt) "دين جديد" else "تسديد"

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Avatar + Name + Date + Type Tag
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = if (isDebt) Color(0xFFFFEDD5) else Color(0xFFD1FAE5),
                        shape = CircleShape,
                        modifier = Modifier.size(42.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = badgeColor,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = customerName,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark,
                                fontSize = 15.sp
                            )
                        )
                        Text(
                            text = op.dateTime.formatDateTime(),
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondaryDark,
                            fontSize = 11.sp
                        )
                    }
                }

                Surface(
                    color = badgeBg,
                    shape = CircleShape
                ) {
                    Text(
                        text = typeLabel,
                        color = badgeColor,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Amount and Note
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = op.amount.formatCurrency(),
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = badgeColor,
                        fontSize = 20.sp
                    )
                )

                if (op.note.isNotBlank()) {
                    Text(
                        text = op.note,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondaryDark,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedButton(
                    onClick = onDelete,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CrimsonRed)
                ) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("حذف العملية", fontSize = 12.sp)
                }
            }
        }
    }
}

