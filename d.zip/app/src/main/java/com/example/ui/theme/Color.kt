package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Reference Image Palette
val RoyalBlue = Color(0xFF1E64F0)         // Vibrant Blue (Buttons, Active Tabs)
val GradientStartBlue = Color(0xFF3B82F6) // Total Debt Gradient Start
val GradientEndBlue = Color(0xFF1D4ED8)   // Total Debt Gradient End

val EmeraldGreen = Color(0xFF00A86B)      // "تسديد" Payment Button Green
val CrimsonRed = Color(0xFFDC2626)        // Debt Red Amount
val OrangeDebt = Color(0xFFEA580C)        // Orange Debt Badge / Arrow

val SurfaceLight = Color(0xFFF3F5F9)      // Soft Off-White Background
val CardSurfaceLight = Color(0xFFFFFFFF)  // Pure White Card Surface
val BorderLight = Color(0xFFE2E8F0)       // Subtle Border Gray

val TextPrimaryDark = Color(0xFF1E293B)   // High Contrast Dark Charcoal Text
val TextSecondaryDark = Color(0xFF64748B) // Secondary Muted Gray Text

// Legacy colors for backwards compatibility
val NavyPrimary = RoyalBlue
val IndigoAccent = RoyalBlue
val AmberWarning = OrangeDebt

