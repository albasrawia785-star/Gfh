package com.example.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.repository.SettingsRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    val overdueDaysThreshold: StateFlow<Int> = settingsRepository.overdueDays
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 30
        )

    private val _uiEvent = MutableSharedFlow<String>()
    val uiEvent: SharedFlow<String> = _uiEvent.asSharedFlow()

    fun logout(onComplete: () -> Unit) {
        viewModelScope.launch {
            settingsRepository.setLoggedIn(false)
            onComplete()
        }
    }

    fun updateOverdueDaysThreshold(days: Int) {
        viewModelScope.launch {
            if (days > 0) {
                settingsRepository.saveOverdueDays(days)
                _uiEvent.emit("تم حفظ عدد أيام التأخير: $days يوم")
            } else {
                _uiEvent.emit("يرجى إدخال عدد أيام صحيح (أكبر من 0)")
            }
        }
    }

    class Factory(
        private val settingsRepository: SettingsRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SettingsViewModel(settingsRepository) as T
        }
    }
}
