package com.example.ui.screens.main

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NorthEast
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Tune
import com.example.util.formatDateOnly
import com.example.util.sendWhatsAppReminder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.Aldion
import com.example.BabyConfig

import com.example.data.model.Customer
import com.example.data.model.Operation
import com.example.data.model.OperationType
import com.example.util.formatDateTime
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GradientEndBlue
import com.example.ui.theme.GradientStartBlue
import com.example.ui.theme.OrangeDebt
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SurfaceLight
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.util.formatCurrency
import com.example.util.formatWithCommas

import androidx.compose.material.icons.filled.WorkspacePremium

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val customers by viewModel.customers.collectAsStateWithLifecycle()
    val totalDebt by viewModel.totalDebt.collectAsStateWithLifecycle()
    val customerCount by viewModel.customerCount.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val isNotificationsEnabled by viewModel.isNotificationsEnabled.collectAsStateWithLifecycle()

    var showAddCustomerDialog by remember { mutableStateOf(false) }
    var showSubscriptionDialog by remember { mutableStateOf(false) }
    var customerToEdit by remember { mutableStateOf<Customer?>(null) }
    var customerToDelete by remember { mutableStateOf<Customer?>(null) }
    var customerForOperation by remember { mutableStateOf<Pair<Customer, OperationType>?>(null) }
    var customerForStatement by remember { mutableStateOf<Customer?>(null) }
    var zeroDebtCustomerToDelete by remember { mutableStateOf<Customer?>(null) }

    LaunchedEffect(Unit) {
        viewModel.uiEvent.collect { event ->
            when (event) {
                is UiMessage.ShowToast -> {
                    Toast.makeText(context, event.message, Toast.LENGTH_SHORT).show()
                }
                is UiMessage.PromptZeroDebtDelete -> {
                    zeroDebtCustomerToDelete = event.customer
                }
                is UiMessage.ShowSubscriptionDialog -> {
                    showSubscriptionDialog = true
                }
            }
        }
    }

    Scaffold(
        containerColor = SurfaceLight,
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    showAddCustomerDialog = true
                },
                containerColor = RoyalBlue,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier.size(56.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "إضافة مدين",
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // 1. Top Welcome Header (Matches Reference Image)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Bell Notification Icon (Left) - Toggle On/Off
                Surface(
                    color = Color.White,
                    shape = CircleShape,
                    shadowElevation = 1.dp,
                    modifier = Modifier.size(46.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.clickable { viewModel.toggleNotifications() }
                    ) {
                        Icon(
                            imageVector = if (isNotificationsEnabled) Icons.Default.NotificationsActive else Icons.Default.NotificationsOff,
                            contentDescription = if (isNotificationsEnabled) "إيقاف التنبيهات" else "تشغيل التنبيهات",
                            tint = if (isNotificationsEnabled) RoyalBlue else TextSecondaryDark,
                            modifier = Modifier.size(22.dp)
                        )
                        if (isNotificationsEnabled) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(RoyalBlue, CircleShape)
                                    .align(Alignment.TopEnd)
                                    .padding(2.dp)
                            )
                        }
                    }
                }

                // Welcome Text + User Avatar (Right)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "مرحبا، ${Aldion.username}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = TextPrimaryDark
                            )
                        )
                        Text(
                            text = "إدارة الديون بسهولة واحترافية",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 12.sp,
                                color = TextSecondaryDark
                            )
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Surface(
                        color = Color(0xFFEFF6FF),
                        shape = CircleShape,
                        modifier = Modifier.size(46.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = RoyalBlue,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }

            // 2. Search & Filter Bar Row (Matches Reference Image)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.updateSearchQuery(it) },
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp),
                    placeholder = {
                        Text("ابحث عن اسم أو رقم هاتف", color = TextSecondaryDark, fontSize = 13.sp)
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "بحث",
                            tint = TextSecondaryDark,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "مسح",
                                    tint = TextSecondaryDark,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = CircleShape,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = RoyalBlue,
                        unfocusedBorderColor = BorderLight
                    )
                )

                // Filter Option Button
                Surface(
                    color = Color.White,
                    shape = CircleShape,
                    shadowElevation = 1.dp,
                    modifier = Modifier.size(50.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.clickable { }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "تصفية",
                            tint = TextPrimaryDark,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 3. Total Debt Blue Summary Card (Matches Reference Image)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        brush = Brush.horizontalGradient(
                            colors = listOf(Color(0xFF2563EB), Color(0xFF1D4ED8))
                        )
                    )
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    // Right Side: Total Debt Label & Amount
                    Column {
                        Text(
                            text = "إجمالي الدين",
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = totalDebt.formatWithCommas(),
                            color = Color.White,
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = BabyConfig.CURRENCY,
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Left Side: Wallet Icon & Customer Count Pill
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = Color.White.copy(alpha = 0.22f),
                            shape = CircleShape
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Group,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "عدد المدينين $customerCount",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Surface(
                            color = Color.White.copy(alpha = 0.25f),
                            shape = CircleShape,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalanceWallet,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 4. Customer List
            if (customers.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.ReceiptLong,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = Color.Gray.copy(alpha = 0.4f)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (searchQuery.isBlank()) "لا يوجد مدينين مضافين بعد" else "لم يتم العثور على نتائج للبحث",
                            color = TextSecondaryDark
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    items(customers, key = { it.id }) { customer ->
                        CustomerCard(
                            customer = customer,
                            onAddDebt = { customerForOperation = Pair(customer, OperationType.DEBT) },
                            onPayment = { customerForOperation = Pair(customer, OperationType.PAYMENT) },
                            onEdit = { customerToEdit = customer },
                            onDelete = { customerToDelete = customer },
                            onViewOperations = { customerForStatement = customer }
                        )
                    }
                }
            }
        }
    }

    // 1. Add Customer Dialog Sheet (Matches Reference Image)
    if (showAddCustomerDialog) {
        AddCustomerDialog(
            onDismiss = { showAddCustomerDialog = false },
            onConfirm = { name, phone, initialDebt ->
                viewModel.addCustomer(name, phone, initialDebt) {
                    showAddCustomerDialog = false
                }
            }
        )
    }

    // 1.5 Subscription Required Dialog (Max 3 Customers)
    if (showSubscriptionDialog) {
        AlertDialog(
            onDismissRequest = { showSubscriptionDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.WorkspacePremium,
                    contentDescription = null,
                    tint = RoyalBlue,
                    modifier = Modifier.size(38.dp)
                )
            },
            title = {
                Text(
                    text = "النسخة الكاملة",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = TextPrimaryDark
                )
            },
            text = {
                Text(
                    text = BabyConfig.SUBSCRIPTION_MESSAGE,
                    fontSize = 14.sp,
                    color = TextSecondaryDark,
                    lineHeight = 22.sp,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = { showSubscriptionDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("حسناً، فهمت", fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(22.dp)
        )
    }

    // 2. Edit Customer Dialog
    customerToEdit?.let { customer ->
        EditCustomerDialog(
            customer = customer,
            onDismiss = { customerToEdit = null },
            onConfirm = { updatedCustomer ->
                viewModel.updateCustomer(updatedCustomer) {
                    customerToEdit = null
                }
            }
        )
    }

    // 3. Delete Customer Confirmation Dialog
    customerToDelete?.let { customer ->
        AlertDialog(
            onDismissRequest = { customerToDelete = null },
            title = { Text("تأكيد الحذف", fontWeight = FontWeight.Bold) },
            text = { Text("هل أنت تأكد من حذف المدين \"${customer.name}\" وكل سجل عملياته؟") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteCustomer(customer)
                        customerToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed)
                ) {
                    Text("حذف")
                }
            },
            dismissButton = {
                TextButton(onClick = { customerToDelete = null }) {
                    Text("إلغاء")
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White
        )
    }

    // 4. Add Operation Dialog (Matches "دين جديد" Card in Reference Image)
    customerForOperation?.let { (customer, type) ->
        OperationDialog(
            customer = customer,
            type = type,
            onDismiss = { customerForOperation = null },
            onSave = { amount, note ->
                viewModel.addOperation(
                    customerId = customer.id,
                    type = type,
                    amount = amount,
                    note = note,
                    onSuccess = { customerForOperation = null }
                )
            }
        )
    }


    // 5. Zero Debt Delete Confirmation Dialog
    zeroDebtCustomerToDelete?.let { customer ->
        AlertDialog(
            onDismissRequest = { zeroDebtCustomerToDelete = null },
            title = { Text("تم تسديد جميع الديون!", fontWeight = FontWeight.Bold) },
            text = {
                Text("وصل إجمالي دين المدين \"${customer.name}\" إلى صفر (0 ${BabyConfig.CURRENCY}).\nهل ترغب في حذف المدين أم الإبقاء عليه؟")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteCustomer(customer)
                        zeroDebtCustomerToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed)
                ) {
                    Text("حذف المدين")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { zeroDebtCustomerToDelete = null }) {
                    Text("الاحتفاظ بالمدين")
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White
        )
    }

    // 6. Customer Operations / Account Statement Dialog
    customerForStatement?.let { customer ->
        CustomerOperationsDialog(
            customer = customer,
            viewModel = viewModel,
            onDismiss = { customerForStatement = null }
        )
    }
}

@Composable
fun CustomerCard(
    customer: Customer,
    onAddDebt: () -> Unit,
    onPayment: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onViewOperations: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onViewOperations() },
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Top Row: Avatar + Name + Phone + Options Menu
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // Avatar Circle
                    val isEven = customer.id % 2L == 0L
                    val avatarBg = if (isEven) Color(0xFFDCFCE7) else Color(0xFFDBEAFE)
                    val avatarTint = if (isEven) Color(0xFF059669) else Color(0xFF2563EB)

                    Surface(
                        color = avatarBg,
                        shape = CircleShape,
                        modifier = Modifier.size(48.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = avatarTint,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = customer.name,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark,
                                fontSize = 17.sp
                            )
                        )
                        if (!customer.phone.isNullOrBlank()) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(top = 2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Phone,
                                    contentDescription = null,
                                    modifier = Modifier.size(13.dp),
                                    tint = TextSecondaryDark
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = customer.phone ?: "",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondaryDark,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }

                // Options Menu Button
                Box {
                    IconButton(
                        onClick = { showMenu = true },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "خيارات",
                            tint = TextSecondaryDark,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("كشف حساب وسجل العمليات") },
                            leadingIcon = { Icon(Icons.Default.History, contentDescription = null, tint = RoyalBlue) },
                            onClick = {
                                showMenu = false
                                onViewOperations()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("تذكير عبر واتساب") },
                            leadingIcon = { Icon(Icons.Default.Send, contentDescription = null, tint = Color(0xFF25D366)) },
                            onClick = {
                                showMenu = false
                                sendWhatsAppReminder(
                                    context = context,
                                    phone = customer.phone,
                                    customerName = customer.name,
                                    debtAmount = customer.debtAmount,
                                    dueDate = System.currentTimeMillis().formatDateOnly()
                                )
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("تعديل البيانات") },
                            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = RoyalBlue) },
                            onClick = {
                                showMenu = false
                                onEdit()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("حذف المدين", color = CrimsonRed) },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = CrimsonRed) },
                            onClick = {
                                showMenu = false
                                onDelete()
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Debt Amount Display Row (Matches Image with Red Text + Orange Trend Arrow Badge)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "الدين الحالي",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondaryDark,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))

                    val isZero = customer.debtAmount == 0L
                    val amountColor = if (isZero) Color(0xFF059669) else CrimsonRed

                    Text(
                        text = customer.debtAmount.formatCurrency(),
                        color = amountColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp
                    )
                }

                // Circular Trend Badge
                val isZero = customer.debtAmount == 0L
                Surface(
                    color = if (isZero) Color(0xFFD1FAE5) else Color(0xFFFFEDD5),
                    shape = CircleShape,
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.NorthEast,
                            contentDescription = null,
                            tint = if (isZero) Color(0xFF059669) else Color(0xFFEA580C),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons Row (Light Green "تسديد" & Light Blue "دين جديد +")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Right Button: "+ دين جديد"
                Button(
                    onClick = onAddDebt,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFEFF6FF),
                        contentColor = Color(0xFF1D4ED8)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(vertical = 10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = Color(0xFF1D4ED8)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("دين جديد", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }

                // Left Button: "تسديد"
                Button(
                    onClick = onPayment,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFECFDF5),
                        contentColor = Color(0xFF059669)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(vertical = 10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Payment,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = Color(0xFF059669)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تسديد", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// 1. Add Customer Dialog Sheet (Matches Bottom-Middle Image Exactly)
@Composable
fun AddCustomerDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, phone: String?, initialDebt: Long) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var initialDebt by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color.White,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Title Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "إضافة مدين جديد",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "إغلاق",
                            tint = TextSecondaryDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Field 1: Customer Name
                Text("اسم المدين", fontWeight = FontWeight.Medium, fontSize = 13.sp, color = TextSecondaryDark)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    placeholder = { Text("اكتب اسم المدين", color = TextSecondaryDark) },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = TextSecondaryDark) },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RoyalBlue,
                        unfocusedBorderColor = BorderLight
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Field 2: Phone Number
                Text("رقم الهاتف (اختياري)", fontWeight = FontWeight.Medium, fontSize = 13.sp, color = TextSecondaryDark)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    placeholder = { Text("اكتب رقم الهاتف", color = TextSecondaryDark) },
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = TextSecondaryDark) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RoyalBlue,
                        unfocusedBorderColor = BorderLight
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Field 3: Initial Debt Amount (Mandatory)
                Text("مبلغ الدين الأولي", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = CrimsonRed)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = initialDebt,
                    onValueChange = { input ->
                        val cleanDigits = input.replace(",", "").filter { it.isDigit() }
                        if (cleanDigits.isEmpty()) {
                            initialDebt = ""
                        } else if (cleanDigits.length <= 15) {
                            cleanDigits.toLongOrNull()?.let { number ->
                                initialDebt = number.formatWithCommas()
                            }
                        }
                    },
                    placeholder = { Text("أدخل مبلغ الدين الأولي", color = TextSecondaryDark) },
                    leadingIcon = {
                        Text(
                            text = BabyConfig.CURRENCY,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondaryDark,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RoyalBlue,
                        unfocusedBorderColor = BorderLight
                    )
                )

                Spacer(modifier = Modifier.height(20.dp))

                val parsedInitialDebt = initialDebt.replace(",", "").toLongOrNull() ?: 0L
                val isValid = name.isNotBlank() && parsedInitialDebt > 0L

                // Action Buttons Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إلغاء", color = TextSecondaryDark)
                    }

                    Button(
                        onClick = { onConfirm(name, phone, parsedInitialDebt) },
                        enabled = isValid,
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1.2f)
                    ) {
                        Text("حفظ", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun EditCustomerDialog(
    customer: Customer,
    onDismiss: () -> Unit,
    onConfirm: (Customer) -> Unit
) {
    var name by remember { mutableStateOf(customer.name) }
    var phone by remember { mutableStateOf(customer.phone ?: "") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color.White,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "تعديل بيانات المدين",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم المدين") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("رقم الهاتف") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إلغاء")
                    }

                    Button(
                        onClick = { onConfirm(customer.copy(name = name, phone = phone)) },
                        enabled = name.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("تحديث")
                    }
                }
            }
        }
    }
}

// 4. Operation Dialog Sheet (Matches "دين جديد" Card in Top-Right Reference Image)
@Composable
fun OperationDialog(
    customer: Customer,
    type: OperationType,
    onDismiss: () -> Unit,
    onSave: (amount: Long, note: String) -> Unit
) {
    var amountText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }

    val isDebt = type == OperationType.DEBT
    val titleStr = if (isDebt) "دين جديد" else "تسديد دين"

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color.White,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = titleStr,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "إغلاق",
                            tint = TextSecondaryDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Customer Field Box
                Text("المدين", fontWeight = FontWeight.Medium, fontSize = 13.sp, color = TextSecondaryDark)
                Spacer(modifier = Modifier.height(4.dp))
                Surface(
                    color = SurfaceLight,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = TextSecondaryDark,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = customer.name,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Amount Input
                Text("المبلغ", fontWeight = FontWeight.Medium, fontSize = 13.sp, color = TextSecondaryDark)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { input ->
                        val cleanDigits = input.replace(",", "").filter { it.isDigit() }
                        if (cleanDigits.isEmpty()) {
                            amountText = ""
                            errorText = null
                        } else if (cleanDigits.length <= 15) {
                            cleanDigits.toLongOrNull()?.let { number ->
                                amountText = number.formatWithCommas()
                                errorText = null
                            }
                        }
                    },
                    placeholder = { Text("0", color = TextSecondaryDark) },
                    leadingIcon = {
                        Text(
                            text = BabyConfig.CURRENCY,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondaryDark,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    isError = errorText != null,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RoyalBlue,
                        unfocusedBorderColor = BorderLight
                    )
                )
                if (errorText != null) {
                    Text(text = errorText ?: "", color = CrimsonRed, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Note Input
                Text("ملاحظات (اختياري)", fontWeight = FontWeight.Medium, fontSize = 13.sp, color = TextSecondaryDark)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    placeholder = { Text("اكتب ملاحظة...", color = TextSecondaryDark) },
                    leadingIcon = { Icon(Icons.Default.EditNote, contentDescription = null, tint = TextSecondaryDark) },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RoyalBlue,
                        unfocusedBorderColor = BorderLight
                    )
                )

                Spacer(modifier = Modifier.height(20.dp))

                val parsedAmount = amountText.replace(",", "").toLongOrNull() ?: 0L

                // Save Button
                Button(
                    onClick = {
                        if (type == OperationType.PAYMENT && parsedAmount > customer.debtAmount) {
                            errorText = "المبلغ المراد تسديده أكبر من الدين الحالي"
                        } else {
                            onSave(parsedAmount, note)
                        }
                    },
                    enabled = parsedAmount > 0,
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("حفظ العملية", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
        }
    }
}


@Composable
fun CustomerOperationsDialog(
    customer: Customer,
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val operations by viewModel.getOperationsForCustomer(customer.id).collectAsStateWithLifecycle(initialValue = emptyList())

    val lastDebtTime = operations.filter { it.type == OperationType.DEBT }.maxOfOrNull { it.dateTime } ?: System.currentTimeMillis()
    val dueDateFormatted = lastDebtTime.formatDateOnly()

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .height(520.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "كشف حساب: ${customer.name}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark
                            )
                        )
                        customer.phone?.let {
                            Text(text = it, fontSize = 12.sp, color = TextSecondaryDark)
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Customer Debt Summary Card with Due Date
                Surface(
                    color = Color(0xFFEFF6FF),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("الدين المتبقي الحالي:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimaryDark)
                            Text(
                                customer.debtAmount.formatCurrency(),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = if (customer.debtAmount > 0) CrimsonRed else EmeraldGreen
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("تاريخ الاستحقاق (آخر دين):", fontSize = 11.sp, color = TextSecondaryDark)
                            Text(dueDateFormatted, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = TextPrimaryDark)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "سجل عمليات المدين (${operations.size} عملية):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondaryDark
                )

                Spacer(modifier = Modifier.height(8.dp))

                if (operations.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("لا توجد عمليات مسجلة للمدين", color = TextSecondaryDark)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(operations, key = { it.id }) { op ->
                            val isDebt = op.type == OperationType.DEBT
                            val cardBg = if (isDebt) Color(0xFFFEF2F2) else Color(0xFFECFDF5)
                            val typeColor = if (isDebt) CrimsonRed else EmeraldGreen
                            val typeTitle = if (op.note == "دين أولي") "دين أولي" else if (isDebt) "دين جديد (+)" else "تسديد (-)"

                            Surface(
                                color = cardBg,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = typeTitle,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = typeColor
                                        )
                                        Text(
                                            text = op.dateTime.formatDateTime(),
                                            fontSize = 10.sp,
                                            color = TextSecondaryDark
                                        )
                                        if (op.note.isNotBlank() && op.note != "دين أولي") {
                                            Text(
                                                text = op.note,
                                                fontSize = 11.sp,
                                                color = TextPrimaryDark
                                            )
                                        }
                                    }

                                    Text(
                                        text = op.amount.formatCurrency(),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = typeColor
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Action buttons: WhatsApp Reminder + Close Statement
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            sendWhatsAppReminder(
                                context = context,
                                phone = customer.phone,
                                customerName = customer.name,
                                debtAmount = customer.debtAmount,
                                dueDate = dueDateFormatted
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF25D366),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "واتساب",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تذكير واتساب", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Text("إغلاق الكشف", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }

            }
        }
    }
}
