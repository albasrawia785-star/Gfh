package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.repository.DebtRepository
import com.example.data.repository.SettingsRepository

class DebtApplication : Application() {
    val database by lazy { AppDatabase.getDatabase(this) }
    val repository by lazy { DebtRepository(database) }
    val settingsRepository by lazy { SettingsRepository(this) }
}

