package com.example.util

import com.example.BabyConfig
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * دالة لتنسيق الأرقام بالفواصل
 * مثل: 1250000 -> 1,250,000
 */
fun Long.formatWithCommas(): String {
    val formatter = NumberFormat.getNumberInstance(Locale.US)
    return formatter.format(this)
}

fun Int.formatWithCommas(): String {
    val formatter = NumberFormat.getNumberInstance(Locale.US)
    return formatter.format(this)
}

/**
 * دالة لتنسيق الأرقام بالفواصل والمضافة إليها العملة من baby.kt
 * مثل: 1250000 -> 1,250,000 د.ع
 */
fun Long.formatCurrency(): String {
    return "${this.formatWithCommas()} ${BabyConfig.CURRENCY}"
}

fun Int.formatCurrency(): String {
    return "${this.formatWithCommas()} ${BabyConfig.CURRENCY}"
}

/**
 * دالة لتنسيق التاريخ والوقت
 */
fun Long.formatDateTime(): String {
    val sdf = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar"))
    return sdf.format(Date(this))
}

/**
 * دالة لتنسيق التاريخ فقط
 */
fun Long.formatDateOnly(): String {
    val sdf = SimpleDateFormat("yyyy/MM/dd", Locale("ar"))
    return sdf.format(Date(this))
}

/**
 * دالة لتنسيق الوقت فقط
 */
fun Long.formatTimeOnly(): String {
    val sdf = SimpleDateFormat("hh:mm a", Locale("ar"))
    return sdf.format(Date(this))
}
