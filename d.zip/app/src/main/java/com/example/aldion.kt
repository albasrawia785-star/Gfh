package com.example

/**
 * =========================================================================
 * مركز التحكم الموحد لتطبيق الديون والزبائن (Aldion Control Center)
 * =========================================================================
 * ملف منفصل وموحد لجميع إعدادات الإدارة، بيانات الزبائن، والديون، والربط مع الفايربيس.
 */
object Aldion {

    // -------------------------------------------------------------------------
    // 1. الإعدادات الأساسية وبيانات الإدارة (سهلة التعديل من أعلى الملف)
    // -------------------------------------------------------------------------
    var username: String = "علي"
    var password: String = "19971997"
    var shopName: String = "محل الديون والخدمات"
    var phoneNumber: String = "07810000000"

    // -------------------------------------------------------------------------
    // 2. إعدادات قاعدة البيانات المحلية والسحابية (Firebase Config)
    // -------------------------------------------------------------------------
    var localDbName: String = "aldion_db"

    // بيانات الربط المباشرة مع الفايربيس (Firebase Configuration) - سهلة التعديل والتبديل
    var firebaseApiKey: String = "AIzaSyBr_VuadUgIsLFEo1sPBV-86Rs9I1ygW5I"
    var firebaseAuthDomain: String = "studio-6071489700-f7b44.firebaseapp.com"
    var firebaseDatabaseUrl: String = "https://studio-6071489700-f7b44-default-rtdb.europe-west1.firebasedatabase.app"
    var firebaseProjectId: String = "studio-6071489700-f7b44"
    var firebaseStorageBucket: String = "studio-6071489700-f7b44.firebasestorage.app"
    var firebaseMessagingSenderId: String = "944277118266"
    var firebaseAppId: String = "1:944277118266:web:1d0bde0603c43830750403"

    var firestoreCustomersCollection: String = "customers"
    var firestoreDebtsCollection: String = "debts"
    var isCloudSyncEnabled: Boolean = true

    /**
     * إرجاع خريطة إعدادات الفايربيس للربط والتخصيص
     */
    fun getFirebaseConfig(): Map<String, String> {
        return mapOf(
            "apiKey" to firebaseApiKey,
            "authDomain" to firebaseAuthDomain,
            "databaseURL" to firebaseDatabaseUrl,
            "projectId" to firebaseProjectId,
            "storageBucket" to firebaseStorageBucket,
            "messagingSenderId" to firebaseMessagingSenderId,
            "appId" to firebaseAppId
        )
    }

    // -------------------------------------------------------------------------
    // 3. الدوال والإجراءات الإدارية
    // -------------------------------------------------------------------------

    /**
     * دالة للتحقق من تسجيل الدخول
     */
    fun checkLogin(inputUser: String, inputPass: String): Boolean {
        val cleanUser = inputUser.trim()
        return (cleanUser.equals(username, ignoreCase = true) || cleanUser.equals("ali", ignoreCase = true)) && inputPass == password
    }

    /**
     * دالة لتحديث البيانات الإدارية بضغطة واحدة
     */
    fun updateSettings(
        newUsername: String? = null,
        newPassword: String? = null,
        newShopName: String? = null,
        newPhoneNumber: String? = null,
        enableCloudSync: Boolean? = null
    ) {
        newUsername?.let { if (it.isNotBlank()) username = it.trim() }
        newPassword?.let { if (it.isNotBlank()) password = it }
        newShopName?.let { if (it.isNotBlank()) shopName = it.trim() }
        newPhoneNumber?.let { if (it.isNotBlank()) phoneNumber = it.trim() }
        enableCloudSync?.let { isCloudSyncEnabled = it }
    }
}

// =========================================================================
// 4. نماذج البيانات (Data Models)
// =========================================================================

/**
 * نموذج بيانات الزبون (Customer)
 */
data class AldionCustomer(
    val id: String = "",
    val name: String = "",
    val phone: String = "",
    val totalDebt: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * نموذج سجل الدين (DebtItem)
 */
data class DebtItem(
    val id: String = "",
    val customerId: String = "",
    val amount: Double = 0.0,
    val note: String = "",
    val dueDate: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isPaid: Boolean = false
)

// =========================================================================
// 5. كلاس التعامل مع الفايربيس (Firebase Firestore Helper)
// =========================================================================

/**
 * كلاس للتعامل مع Firebase Firestore يستخدم أسماء المجموعات المحددة في [Aldion] تلقائياً
 */
class AldionFirebaseManager {

    /**
     * اسم مجموعة الزبائن المحددة في مركز التحكم Aldion
     */
    val customersCollection: String
        get() = Aldion.firestoreCustomersCollection

    /**
     * اسم مجموعة الديون المحددة في مركز التحكم Aldion
     */
    val debtsCollection: String
        get() = Aldion.firestoreDebtsCollection

    /**
     * حالة المزامنة السحابية
     */
    val isSyncActive: Boolean
        get() = Aldion.isCloudSyncEnabled

    /**
     * تحويل بيانات الزبون إلى Map مخصصة للرفع على Firestore
     */
    fun customerToMap(customer: AldionCustomer): Map<String, Any> {
        return mapOf(
            "id" to customer.id,
            "name" to customer.name,
            "phone" to customer.phone,
            "totalDebt" to customer.totalDebt,
            "createdAt" to customer.createdAt
        )
    }

    /**
     * تحويل بيانات سجل الدين إلى Map مخصصة للرفع على Firestore
     */
    fun debtItemToMap(debt: DebtItem): Map<String, Any> {
        return mapOf(
            "id" to debt.id,
            "customerId" to debt.customerId,
            "amount" to debt.amount,
            "note" to debt.note,
            "dueDate" to debt.dueDate,
            "timestamp" to debt.timestamp,
            "isPaid" to debt.isPaid
        )
    }
}
